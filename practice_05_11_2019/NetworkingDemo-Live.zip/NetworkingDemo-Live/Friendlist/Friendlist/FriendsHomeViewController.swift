//
//  FriendsHomeViewController.swift
//  Friendlist
//
//  Created by Mufakkharul Islam Nayem on 10/25/19.
//  Copyright © 2019 Mufakkharul Islam Nayem. All rights reserved.
//

import UIKit

class FriendsHomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

}

//
//  FriendListViewController.swift
//  Friendlist
//
//  Created by Mufakkharul Islam Nayem on 10/24/19.
//  Copyright © 2019 Mufakkharul Islam Nayem. All rights reserved.
//

import UIKit
import Alamofire

class FriendListViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!

    var user: String?

    private var sections = [Section]() {
        didSet {
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }

    @discardableResult
    private func fetchFriends() -> DataRequest {
        return
            // get method
            Alamofire.request("https://private-8940f3-friends13.apiary-mock.com/friends")
                .responseData { (response) in
                    switch response.result {
                    case .success(let data):
                        do {
                            let friends = try JSONDecoder().decode([Friend].self, from: data)
                            self.sections = Section.alphabaticallySectionedFriends(friends: friends)
                        } catch {
                            print(error)
                        }
                    case .failure(let error):
                        print(error)
                    }
        }
    }

    func postFriend() {
        let parameters = [
          "name": "Beverly Cunningham",
          "countryName": "Guadeloupe",
          "bio": "In scelerisque scelerisque dui. Suspendisse ac metus vitae velit"
        ]
        Alamofire.request("https://private-8940f3-friends13.apiary-mock.com/friends", method: .post, parameters: parameters).responseJSON { (response) in
            if let value = response.result.value {
                print(value)
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 80
        tableView.register(UINib(nibName: "FriendCell", bundle: Bundle.main) , forCellReuseIdentifier: "FriendCell")
        fetchFriends()
//        postFriend()
    }

    /*deinit {
        print("\(String(describing: self)) deinitialized")
    }*/

    @IBAction func doneButtonDidTap(_ sender: UIBarButtonItem) {
        dismiss(animated: true)
    }

}

extension FriendListViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sections[section].friends.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FriendCell", for: indexPath) as! FriendCell
        let friend = sections[indexPath.section].friends[indexPath.row]
        cell.nameLabel.text = friend.name
        cell.countryLabel.text = friend.countryName
        cell.aboutLabel.text = friend.bio
        return cell
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let title = sections[section].name
        return title
    }

    func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        let indexTitles = sections.map { $0.name }
        return indexTitles
    }
}

extension FriendListViewController: UITableViewDelegate {

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }

    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { (_, _, actionPerformed) in
            self.sections[indexPath.section].friends.remove(at: indexPath.row)
            actionPerformed(true)
        }
        deleteAction.image = UIImage(systemName: "trash")
        deleteAction.backgroundColor = .systemPink
        let swipeActionConfiguration = UISwipeActionsConfiguration(actions: [deleteAction])
        return swipeActionConfiguration
    }

}
